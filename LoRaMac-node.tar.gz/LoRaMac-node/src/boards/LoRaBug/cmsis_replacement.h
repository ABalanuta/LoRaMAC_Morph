/*
 * cmsis_replacement.h
 *
 *  Created on: Jan 8, 2017
 *      Author: craig
 */

#ifndef LORARADIO_CMSIS_REPLACEMENT_H_
#define LORARADIO_CMSIS_REPLACEMENT_H_


void __enable_irq( );
void __disable_irq( );

/**
 *
 * @param Delay Milliseconds
 */
void HAL_Delay(uint32_t Delay);

/* Exported macro ------------------------------------------------------------*/
#ifdef  USE_FULL_ASSERT
/**
  * @brief  The assert_param macro is used for function's parameters check.
  * @param  expr: If expr is false, it calls assert_failed function
  *         which reports the name of the source file and the source
  *         line number of the call that failed.
  *         If expr is true, it returns no value.
  * @retval None
  */
  #define assert_param(expr) ((expr) ? (void)0 : assert_failed((uint8_t *)__FILE__, __LINE__))
/* Exported functions ------------------------------------------------------- */
  void assert_failed(uint8_t* file, uint32_t line);
#else
  #define assert_param(expr) ((void)0)
#endif /* USE_FULL_ASSERT */


#endif /* LORARADIO_CMSIS_REPLACEMENT_H_ */
